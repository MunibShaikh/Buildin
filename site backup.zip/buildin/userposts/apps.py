from django.apps import AppConfig


class UserpostsConfig(AppConfig):
    name = 'userposts'
