from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
from webapp.models import Post
from webapp.forms import PostForm
import datetime
import itertools
import sqlite3
import functools
from django.contrib.auth.models import User


def showpost(request):  
    posts = request.user.user_posts.filter()
    author=request.user.get_username()
    context={'posts':posts,'author':author,'counter': functools.partial(next, itertools.count())} 
    return render(request,"userposts/userposts.html",context)


def makepost(request):
    if request.method == "POST":
        form = PostForm(request.POST,request.FILES)  
        if form.is_valid():  
            try:
                p = form.save(commit=False)
                p.author = request.user
                form.save()  
                # return render(request,'userposts/userPosts.html') 
                return redirect('showpost')
            except:  
                pass  
    else:  
        form = PostForm()  
    return render(request,'userposts/makepost.html',{'form':form})  


def editPost(request, sno):  
    post = Post.objects.get(sno=sno)
    context={'post':post}
    post_author=post.author
    auth_user=request.user.get_username()
    if str(post_author)==str(auth_user):
        return render(request,'userposts/editPost.html',context)
    else:
        return HttpResponse('not valid id')

def updatePost(request, sno):
    post = Post.objects.get(sno=sno)
    # form = PostForm(request.FILES,request.POST, instance = post)
    form = PostForm(request.POST,request.FILES,instance=post)
    post_author=post.author
    auth_user=request.user.get_username()
    if str(post_author)==str(auth_user):
        if form.is_valid():  
            form.save()
            return redirect("showpost")
    else:
        return HttpResponse('not valid id')
    return HttpResponse('This is this is blog')
    # return render(request, 'userposts/editPost.html',{'post':post})

def deletePost(request, sno):
    post = Post.objects.get(sno=sno)  
    post.delete()  
    return redirect("showpost")
