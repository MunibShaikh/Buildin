from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
from webapp.models import Post
from webapp.forms import PostForm
import datetime
import itertools
import sqlite3
import functools
from django.contrib.auth.models import User

# Create your views here.
def hello(request):
    # collect data from models (database/table)
    #
    return HttpResponse('this is hello')