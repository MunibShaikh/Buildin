from django.shortcuts import render, HttpResponse

# Create your views here.
def webappHome(request):
    return render(request,'webapp/webappHome.html')

def webappPost(request, slug):
    return render(request,'webapp/webappPost.html')
    # return HttpResponse(f'This is this is blog {slug}')