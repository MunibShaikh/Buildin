from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
from webapp.models import Post
import datetime
import itertools
import sqlite3
import functools
from django.contrib.auth.models import User

# Create your views here.
def webappHome(request):
    # collect data from models (database/table)
    #
    allposts = Post.objects.all()
    context={'allposts': allposts}
    return render(request,'webapp/webappHome.html',context)


# def makepost(request):

#     if request.user.is_authenticated:
#         if request.method=='POST':
#             print('hello you are using makepost')
#             title=request.POST['title']
#             subject=request.POST['subject']
#             description=request.POST['description']
#             author=request.user.get_username()
#             now = datetime.datetime.now()
#             post=Post(author=author,title=title,slug=subject,content=description,timestamp=now)
#             post.save()
#             messages.success(request,'your model has been posted successfully')
#             print(title,subject,description,author,now)
#         return render(request,'webapp/makepost.html')
#     else:
#         messages.warning(request,'Login your account for posting something')
#         return render(request,'webapp/makepost.html')

# def userPosts(request):
#     if request.user.is_authenticated:
#         postDisp = Post.objects.all()
#         author=request.user.get_username()
#         context={'postDisp': postDisp,'author':author,'counter': functools.partial(next, itertools.count())}
#         return render(request,'webapp/userPosts.html',context)

# def editPost(request,sno):
#     post = Post.objects.get(sno=sno)
#     context={'post':post}
#     return render(request,'webapp/editPost.html',context)

# def updatePost(request,sno):
#     Post.objects.filter(sno=sno).update(title=title)
#     return render(request,'webapp/userPosts.html')

def webappPost(request, slug):
    post=Post.objects.filter(slug=slug).first()
    context={'post':post}
    return render(request,'webapp/webappPost.html',context)
    # return HttpResponse(f'This is this is blog {slug}')
