from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
from webapp.models import Post
from webapp.forms import PostForm
import datetime
import itertools
import sqlite3
import functools
from django.contrib.auth.models import User


def showpost(request):  
    posts = Post.objects.all()
    author=request.user.get_username()
    context={'posts':posts,'author':author,'counter': functools.partial(next, itertools.count())} 
    return render(request,"userposts/userposts.html",context)


def makepost(request):
    if request.method == "POST":  
        form = PostForm(request.POST)  
        if form.is_valid():  
            try:
                form.save()  
                # return render(request,'userposts/userPosts.html') 
                return redirect('showpost')
            except:  
                pass  
    else:  
        form = PostForm()  
    return render(request,'userposts/makepost.html',{'form':form})  


def editPost(request, sno):  
    post = Post.objects.get(sno=sno)
    context={'post':post}
    return render(request,'userposts/editPost.html',context)

def updatePost(request, sno):
    post = Post.objects.get(sno=sno)
    form = PostForm(request.POST, instance = post)
    print(post.content)
    if form.is_valid():  
        form.save()
        return redirect("showpost")
    return HttpResponse('This is this is blog')
    # return render(request, 'userposts/editPost.html',{'post':post})

def deletePost(request, sno):
    post = Post.objects.get(sno=sno)  
    post.delete()  
    return redirect("showpost")
