from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
from webapp.models import Post
from django.contrib.auth.models import User

# Create your views here.
def webappHome(request):
    # collect data from models (database/table)
    #
    allposts = Post.objects.all()
    context={'allposts': allposts}
    return render(request,'webapp/webappHome.html',context)

def webappPost(request, slug):
    post=Post.objects.filter(slug=slug).first()
    context={'post':post}
    return render(request,'webapp/webappPost.html',context)
    # return HttpResponse(f'This is this is blog {slug}')
