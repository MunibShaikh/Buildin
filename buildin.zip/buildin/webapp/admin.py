from django.contrib import admin
from webapp.models import Post
# Register your models here.
admin.site.register(Post)
